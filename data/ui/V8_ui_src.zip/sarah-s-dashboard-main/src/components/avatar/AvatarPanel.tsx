import { useState, useEffect, Suspense } from 'react';
import { Maximize2, ExternalLink, Hand, User, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useSarahStore } from '@/stores/useSarahStore';
import { api } from '@/lib/api';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { AvatarBackground } from './AvatarBackground';
import { WebcamOverlay } from './WebcamOverlay';
import { Avatar3D } from './Avatar3D';
// Import optimized WebP with fallback PNG using vite-imagetools
import sarahAvatarWebp from '@/assets/sarah-avatar.png?format=webp&w=640';
import sarahAvatarPng from '@/assets/sarah-avatar.png?w=640';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface AvatarState {
  mode: string;
  expression: string;
  speaking: boolean;
  listening: boolean;
}

export function AvatarPanel() {
  const { mediaState, setScreenMode, toggleWebcam } = useSarahStore();
  const [avatarState, setAvatarState] = useState<AvatarState>({
    mode: 'avatar_2d',
    expression: 'neutral',
    speaking: false,
    listening: false,
  });
  const [webcamVisible, setWebcamVisible] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);

  const screenModes = [
    { value: 'avatar_2d', label: 'Avatar 2D' },
    { value: 'avatar_3d', label: 'Avatar 3D' },
    { value: 'desktop_mirror', label: 'Desktop Mirror' },
    { value: 'media', label: 'Media Display' },
    { value: 'idle', label: 'Idle' },
  ];

  const avatarActions = [
    { id: 'wave', label: 'Wave', icon: Hand },
    { id: 'walk', label: 'Walk', icon: User },
    { id: 'sit', label: 'Sit', icon: User },
    { id: 'idle', label: 'Idle', icon: User },
    { id: 'think', label: 'Think', icon: User },
  ];

  // Fetch initial avatar state
  useEffect(() => {
    const fetchAvatarState = async () => {
      try {
        const state = await api.avatar.getState();
        setAvatarState(state);
      } catch (error) {
        console.error('Failed to fetch avatar state:', error);
      }
    };

    fetchAvatarState();
    
    // Poll for state updates
    const interval = setInterval(fetchAvatarState, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleModeChange = async (mode: string) => {
    setScreenMode(mode as typeof mediaState.screenMode);
    
    try {
      await api.avatar.setMode(mode as any);
      setAvatarState(prev => ({ ...prev, mode }));
    } catch (error) {
      console.error('Failed to set avatar mode:', error);
    }
  };

  const handleAction = async (action: string) => {
    setIsAnimating(true);
    
    try {
      await api.avatar.triggerAnimation(action);
      toast.success(`Animation: ${action}`);
    } catch (error) {
      console.error('Failed to trigger animation:', error);
      toast.info('Animation feature coming soon');
    } finally {
      setTimeout(() => setIsAnimating(false), 1000);
    }
  };

  const handleExpression = async (expression: string) => {
    try {
      await api.avatar.setExpression(expression);
      setAvatarState(prev => ({ ...prev, expression }));
    } catch (error) {
      console.error('Failed to set expression:', error);
    }
  };

  const is3DMode = mediaState.screenMode === 'avatar_3d';

  return (
    <div className="relative aspect-video bg-gradient-to-b from-background/80 to-background border-b border-sidebar-border overflow-hidden">
      {/* Animated Background */}
      <AvatarBackground />
      
      {/* Avatar Display - 2D or 3D based on mode */}
      <div className="absolute inset-0 flex items-center justify-center z-10">
        {is3DMode ? (
          <Suspense fallback={
            <div className="flex items-center justify-center h-full text-muted-foreground">
              Loading 3D Avatar...
            </div>
          }>
            <Avatar3D 
              speaking={avatarState.speaking}
              listening={avatarState.listening}
              expression={avatarState.expression}
            />
          </Suspense>
        ) : (
          <picture>
            <source srcSet={sarahAvatarWebp} type="image/webp" />
            <img 
              src={sarahAvatarPng} 
              alt="Sarah AI Avatar" 
              fetchPriority="high"
              width={640}
              height={360}
              className={cn(
                "w-full h-full object-cover opacity-90 transition-all duration-300",
                isAnimating && "scale-105",
                avatarState.speaking && "animate-pulse"
              )}
            />
          </picture>
        )}
      </div>

      {/* Webcam Overlay */}
      <WebcamOverlay 
        enabled={mediaState.webcamEnabled}
        visible={webcamVisible}
        onToggleVisible={() => setWebcamVisible(!webcamVisible)}
      />
      
      {/* Screen Mode Controls */}
      <div className="absolute bottom-2 left-2 right-2 flex items-center gap-2 z-20">
        <Select 
          value={mediaState.screenMode} 
          onValueChange={handleModeChange}
        >
          <SelectTrigger className="h-8 text-xs bg-background/80 backdrop-blur border-border flex-1">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {screenModes.map((mode) => (
              <SelectItem key={mode.value} value={mode.value} className="text-xs">
                {mode.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Avatar Actions hidden - controlled by backend/AI */}

        <Button variant="ghost" size="icon" className="h-8 w-8 bg-background/80 backdrop-blur">
          <Maximize2 className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 bg-background/80 backdrop-blur">
          <ExternalLink className="h-4 w-4" />
        </Button>
      </div>

      {/* Status Indicator */}
      <div className="absolute top-2 right-2 z-20 flex flex-col gap-1 items-end">
        <div className="px-2 py-1 bg-background/80 backdrop-blur rounded text-xs text-muted-foreground flex items-center gap-1.5">
          <span className={cn(
            "w-1.5 h-1.5 rounded-full",
            avatarState.speaking ? "bg-status-warning animate-pulse" :
            avatarState.listening ? "bg-status-info animate-pulse" :
            "bg-status-online animate-pulse"
          )} />
          {avatarState.speaking ? 'Speaking' : 
           avatarState.listening ? 'Listening' : 
           'Ready'}
        </div>
        
        {/* Webcam toggle when hidden */}
        {mediaState.webcamEnabled && !webcamVisible && (
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-xs bg-background/80 backdrop-blur"
            onClick={() => setWebcamVisible(true)}
          >
            Show Webcam
          </Button>
        )}
      </div>

    </div>
  );
}
