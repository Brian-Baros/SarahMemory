import { useState, useRef, useEffect } from 'react';
import { Video, VideoOff, X, Move, Maximize2, Minimize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface WebcamOverlayProps {
  enabled: boolean;
  visible: boolean;
  onToggleVisible: () => void;
}

export function WebcamOverlay({ enabled, visible, onToggleVisible }: WebcamOverlayProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [position, setPosition] = useState({ x: 10, y: 10 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!enabled || !visible) {
      // Stop stream when disabled
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
        videoRef.current.srcObject = null;
      }
      return;
    }

    const startWebcam = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            width: { ideal: 320 },
            height: { ideal: 240 },
            facingMode: 'user'
          } 
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setHasPermission(true);
        }
      } catch (error) {
        console.error('Webcam access denied:', error);
        setHasPermission(false);
      }
    };

    startWebcam();

    return () => {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [enabled, visible]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button')) return;
    
    setIsDragging(true);
    const rect = containerRef.current?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !containerRef.current?.parentElement) return;
      
      const parentRect = containerRef.current.parentElement.getBoundingClientRect();
      const containerRect = containerRef.current.getBoundingClientRect();
      
      let newX = e.clientX - parentRect.left - dragOffset.x;
      let newY = e.clientY - parentRect.top - dragOffset.y;
      
      // Constrain to parent bounds
      newX = Math.max(0, Math.min(newX, parentRect.width - containerRect.width));
      newY = Math.max(0, Math.min(newY, parentRect.height - containerRect.height));
      
      setPosition({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset]);

  if (!enabled || !visible) return null;

  return (
    <div
      ref={containerRef}
      className={cn(
        "absolute z-20 rounded-xl overflow-hidden border border-border/50 shadow-lg",
        "bg-background/90 backdrop-blur-sm",
        "transition-all duration-200",
        isDragging && "cursor-grabbing",
        isExpanded ? "w-48 h-36" : "w-32 h-24"
      )}
      style={{
        left: position.x,
        top: position.y,
      }}
      onMouseDown={handleMouseDown}
    >
      {hasPermission === false ? (
        <div className="w-full h-full flex items-center justify-center p-2 text-center">
          <div className="text-xs text-muted-foreground">
            <VideoOff className="h-4 w-4 mx-auto mb-1" />
            Camera access denied
          </div>
        </div>
      ) : (
        <>
          <video
            ref={videoRef}
            autoPlay
            muted
            playsInline
            className="w-full h-full object-cover"
          />
          
          {/* Controls */}
          <div className="absolute top-1 right-1 flex gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-5 w-5 bg-background/80 hover:bg-background"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? (
                <Minimize2 className="h-3 w-3" />
              ) : (
                <Maximize2 className="h-3 w-3" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-5 w-5 bg-background/80 hover:bg-background"
              onClick={onToggleVisible}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
          
          {/* Drag handle indicator */}
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2">
            <Move className="h-3 w-3 text-muted-foreground/50" />
          </div>
        </>
      )}
    </div>
  );
}
