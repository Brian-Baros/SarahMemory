import { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
  OrbitControls, 
  Sphere, 
  Float,
  Sparkles,
  Ring,
  Torus,
} from '@react-three/drei';
import * as THREE from 'three';

interface AvatarMeshProps {
  speaking: boolean;
  listening: boolean;
  expression: string;
}

// Primary holographic colors - matching 2D image
const HOLO_PRIMARY = '#00d4ff';      // Cyan/teal
const HOLO_SECONDARY = '#00ffcc';    // Green-cyan
const HOLO_DARK = '#0a1520';         // Deep dark blue-black
const HOLO_MID = '#102030';          // Mid dark blue
const HOLO_ACCENT = '#00b8d4';       // Accent cyan
const HOLO_GLOW = '#40e0d0';         // Turquoise glow

// Holographic ring effect
function HoloRing({ radius, speed, color, yPos = 0 }: { radius: number; speed: number; color: string; yPos?: number }) {
  const ringRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (ringRef.current) {
      ringRef.current.rotation.z = state.clock.elapsedTime * speed;
    }
  });

  return (
    <Ring
      ref={ringRef}
      args={[radius, radius + 0.015, 64]}
      position={[0, yPos, 0]}
      rotation={[Math.PI / 2, 0, 0]}
    >
      <meshBasicMaterial color={color} transparent opacity={0.4} side={THREE.DoubleSide} />
    </Ring>
  );
}

// Holographic hair strand with wave animation
function HairStrand({ 
  position, 
  rotation, 
  length, 
  delay,
  thickness = 0.018
}: { 
  position: [number, number, number]; 
  rotation: [number, number, number]; 
  length: number; 
  delay: number;
  thickness?: number;
}) {
  const strandRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (strandRef.current) {
      // Natural hair sway
      strandRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 1.5 + delay) * 0.08;
      strandRef.current.rotation.x = Math.cos(state.clock.elapsedTime * 1.2 + delay) * 0.04;
    }
  });

  return (
    <group ref={strandRef} position={position} rotation={rotation}>
      {/* Hair strand - holographic */}
      <mesh>
        <capsuleGeometry args={[thickness, length, 6, 12]} />
        <meshStandardMaterial 
          color={HOLO_DARK}
          metalness={0.85} 
          roughness={0.2}
          emissive={HOLO_PRIMARY}
          emissiveIntensity={0.08}
        />
      </mesh>
      {/* Highlight strand - glowing */}
      <mesh position={[thickness * 0.3, 0, thickness * 0.2]}>
        <capsuleGeometry args={[thickness * 0.3, length * 0.9, 4, 8]} />
        <meshBasicMaterial 
          color={HOLO_PRIMARY}
          transparent
          opacity={0.15}
        />
      </mesh>
    </group>
  );
}

// Holographic hair layer
function HolographicHair({ primaryColor }: { primaryColor: string }) {
  const hairGroupRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (hairGroupRef.current) {
      // Subtle overall hair movement
      hairGroupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.02;
    }
  });

  return (
    <group ref={hairGroupRef} position={[0, 0.4, -0.15]}>
      {/* Top hair volume - holographic */}
      <Sphere args={[0.5, 32, 32]} scale={[1.4, 0.55, 1.1]} position={[0, 0.25, 0]}>
        <meshStandardMaterial 
          color={HOLO_DARK}
          metalness={0.9} 
          roughness={0.15}
          emissive={primaryColor}
          emissiveIntensity={0.06}
        />
      </Sphere>
      
      {/* Hair energy lines */}
      <mesh position={[0, 0.35, 0.15]} rotation={[0.3, 0, 0]}>
        <capsuleGeometry args={[0.02, 0.25, 4, 8]} />
        <meshBasicMaterial color={primaryColor} transparent opacity={0.25} />
      </mesh>
      
      {/* Left side hair - flowing layers */}
      <group position={[-0.45, -0.2, 0.1]}>
        {Array.from({ length: 12 }).map((_, i) => (
          <HairStrand 
            key={`left-${i}`}
            position={[
              (i % 4) * 0.06 - 0.1, 
              -Math.floor(i / 4) * 0.25 - i * 0.05, 
              (i % 3) * 0.04
            ]} 
            rotation={[0.15, 0.25, 0.12 + (i % 4) * 0.04]}
            length={0.5 + i * 0.08}
            delay={i * 0.4}
            thickness={0.02 - (i % 3) * 0.003}
          />
        ))}
      </group>
      
      {/* Right side hair - flowing layers */}
      <group position={[0.45, -0.2, 0.1]}>
        {Array.from({ length: 12 }).map((_, i) => (
          <HairStrand 
            key={`right-${i}`}
            position={[
              -(i % 4) * 0.06 + 0.1, 
              -Math.floor(i / 4) * 0.25 - i * 0.05, 
              (i % 3) * 0.04
            ]} 
            rotation={[0.15, -0.25, -0.12 - (i % 4) * 0.04]}
            length={0.5 + i * 0.08}
            delay={i * 0.4 + 0.2}
            thickness={0.02 - (i % 3) * 0.003}
          />
        ))}
      </group>

      {/* Back hair - fuller cascade */}
      <group position={[0, -0.35, -0.25]}>
        {Array.from({ length: 18 }).map((_, i) => {
          const row = Math.floor(i / 6);
          const col = i % 6;
          return (
            <HairStrand 
              key={`back-${i}`}
              position={[
                (col - 2.5) * 0.13, 
                -row * 0.3, 
                -row * 0.08
              ]} 
              rotation={[0.5 + row * 0.1, 0, (col - 2.5) * 0.04]}
              length={0.7 + row * 0.25}
              delay={i * 0.25}
              thickness={0.022 - row * 0.003}
            />
          );
        })}
      </group>

      {/* Front bangs/framing pieces */}
      <group position={[0, 0, 0.35]}>
        <HairStrand position={[-0.32, -0.1, 0]} rotation={[0.2, 0.4, 0.25]} length={0.35} delay={0} thickness={0.018} />
        <HairStrand position={[-0.28, -0.05, 0.02]} rotation={[0.15, 0.35, 0.2]} length={0.3} delay={0.5} thickness={0.015} />
        <HairStrand position={[0.32, -0.1, 0]} rotation={[0.2, -0.4, -0.25]} length={0.35} delay={0.25} thickness={0.018} />
        <HairStrand position={[0.28, -0.05, 0.02]} rotation={[0.15, -0.35, -0.2]} length={0.3} delay={0.75} thickness={0.015} />
      </group>
    </group>
  );
}

// Holographic ear component
function Ear({ side, primaryColor }: { side: 'left' | 'right'; primaryColor: string }) {
  const xPos = side === 'left' ? -0.62 : 0.62;
  const scaleX = side === 'left' ? 1 : -1;
  
  return (
    <group position={[xPos, 0, 0]} scale={[scaleX, 1, 1]}>
      {/* Outer ear shell - holographic */}
      <Sphere args={[0.08, 16, 16]} scale={[0.35, 1, 0.6]} position={[0, 0, 0]}>
        <meshStandardMaterial 
          color={HOLO_MID}
          metalness={0.9} 
          roughness={0.15}
          emissive={primaryColor}
          emissiveIntensity={0.05}
        />
      </Sphere>
      {/* Inner ear detail */}
      <Sphere args={[0.04, 12, 12]} scale={[0.4, 0.8, 0.5]} position={[0.01, 0, 0.02]}>
        <meshStandardMaterial 
          color={HOLO_DARK}
          metalness={0.85} 
          roughness={0.2}
          emissive={primaryColor}
          emissiveIntensity={0.08}
        />
      </Sphere>
      {/* Earlobe */}
      <Sphere args={[0.035, 12, 12]} scale={[0.5, 0.7, 0.6]} position={[0.01, -0.07, 0.01]}>
        <meshStandardMaterial 
          color={HOLO_MID}
          metalness={0.9} 
          roughness={0.15}
          emissive={primaryColor}
          emissiveIntensity={0.04}
        />
      </Sphere>
      {/* Tech ear piece accent */}
      <Ring args={[0.025, 0.035, 16]} rotation={[0, Math.PI / 2, 0]} position={[0.02, 0, 0.01]}>
        <meshBasicMaterial color={primaryColor} transparent opacity={0.6} side={THREE.DoubleSide} />
      </Ring>
    </group>
  );
}

// Holographic blinking eye component
function Eye({ 
  position, 
  primaryColor, 
  eyeBlink, 
  squint,
  side 
}: { 
  position: [number, number, number]; 
  primaryColor: string; 
  eyeBlink: number;
  squint: number;
  side: 'left' | 'right';
}) {
  const pupilRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (pupilRef.current) {
      // Subtle eye movement for life
      const lookX = Math.sin(state.clock.elapsedTime * 0.5) * 0.008;
      const lookY = Math.cos(state.clock.elapsedTime * 0.7) * 0.005;
      pupilRef.current.position.x = lookX;
      pupilRef.current.position.y = lookY;
    }
  });

  const blinkAmount = Math.max(eyeBlink, squint);
  const mirrorX = side === 'right' ? -1 : 1;

  return (
    <group position={position}>
      {/* Eye socket glow */}
      <Sphere args={[0.12, 32, 32]} scale={[1.4, 1, 0.7]}>
        <meshBasicMaterial color={primaryColor} transparent opacity={0.15} />
      </Sphere>
      
      {/* Upper eyelid - holographic */}
      <group position={[0, 0.05, 0.03]}>
        <Sphere 
          args={[0.11, 32, 16]} 
          scale={[1.5, 0.4 + blinkAmount * 0.6, 0.6]}
          position={[0, -blinkAmount * 0.04, 0]}
        >
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.05}
          />
        </Sphere>
      </group>
      
      {/* Lower eyelid */}
      <group position={[0, -0.06, 0.02]}>
        <Sphere 
          args={[0.09, 32, 16]} 
          scale={[1.4, 0.25 + blinkAmount * 0.2, 0.5]}
          position={[0, blinkAmount * 0.02, 0]}
        >
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.05}
          />
        </Sphere>
      </group>
      
      {/* Eye - holographic glow (no white sclera) */}
      <Sphere 
        args={[0.095, 32, 32]} 
        scale={[1.5, 0.95 - blinkAmount * 0.85, 0.6]}
      >
        <meshStandardMaterial 
          color={HOLO_DARK}
          metalness={0.8} 
          roughness={0.2}
          emissive={primaryColor}
          emissiveIntensity={0.1}
        />
      </Sphere>
      
      {/* Iris - bright holographic */}
      <Sphere 
        args={[0.06, 32, 32]} 
        position={[0, 0, 0.025]}
        scale={[1.2, 1 - blinkAmount * 0.9, 1]}
      >
        <meshBasicMaterial 
          color={primaryColor}
          transparent
          opacity={0.9}
        />
      </Sphere>
      
      {/* Pupil - dark center */}
      <group ref={pupilRef}>
        <Sphere 
          args={[0.028, 16, 16]} 
          position={[0, 0, 0.045]}
          scale={[1, 1 - blinkAmount * 0.9, 1]}
        >
          <meshBasicMaterial color={HOLO_DARK} />
        </Sphere>
      </group>
      
      {/* Eye highlight - cyan specular */}
      <Sphere args={[0.014, 16, 16]} position={[0.018 * mirrorX, 0.018, 0.055]}>
        <meshBasicMaterial color={HOLO_GLOW} transparent opacity={0.8 * (1 - blinkAmount * 0.8)} />
      </Sphere>
      <Sphere args={[0.008, 12, 12]} position={[-0.012 * mirrorX, -0.008, 0.05]}>
        <meshBasicMaterial color={primaryColor} transparent opacity={0.5 * (1 - blinkAmount * 0.8)} />
      </Sphere>
      
      {/* Eyelashes - holographic upper */}
      <group position={[0, 0.065, 0.02]}>
        {[-0.05, -0.03, -0.01, 0.01, 0.03, 0.05].map((x, i) => (
          <mesh 
            key={i} 
            position={[x, 0, 0]} 
            rotation={[0.35 - blinkAmount * 0.3, 0, (i - 2.5) * 0.12 * mirrorX]}
          >
            <capsuleGeometry args={[0.003, 0.035 + Math.abs(i - 2.5) * 0.005, 2, 4]} />
            <meshBasicMaterial color={HOLO_DARK} />
          </mesh>
        ))}
      </group>
      
      {/* Eyelashes - lower */}
      <group position={[0, -0.055, 0.015]}>
        {[-0.03, 0, 0.03].map((x, i) => (
          <mesh 
            key={i} 
            position={[x, 0, 0]} 
            rotation={[-0.3 + blinkAmount * 0.2, 0, (i - 1) * 0.08 * mirrorX]}
          >
            <capsuleGeometry args={[0.002, 0.015, 2, 4]} />
            <meshBasicMaterial color={HOLO_DARK} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

// Holographic feminine face component
function HolographicFace({ primaryColor, mouthOpen, eyeBlink, squint }: { primaryColor: string; mouthOpen: number; eyeBlink: number; squint: number }) {
  return (
    <group>
      {/* Face contour highlights - holographic */}
      <group position={[0, 0, 0.45]}>
        {/* Cheekbones - holographic glow */}
        <Sphere args={[0.12, 16, 16]} position={[-0.35, 0, 0.18]} scale={[1.2, 0.8, 0.6]}>
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </Sphere>
        <Sphere args={[0.12, 16, 16]} position={[0.35, 0, 0.18]} scale={[1.2, 0.8, 0.6]}>
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </Sphere>
        
        {/* Cheek accent - holographic glow instead of blush */}
        <Sphere args={[0.07, 16, 16]} position={[-0.32, -0.05, 0.25]} scale={[1.1, 0.7, 0.4]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.08} />
        </Sphere>
        <Sphere args={[0.07, 16, 16]} position={[0.32, -0.05, 0.25]} scale={[1.1, 0.7, 0.4]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.08} />
        </Sphere>
      </group>

      {/* Eyes */}
      <Eye position={[-0.22, 0.12, 0.72]} primaryColor={primaryColor} eyeBlink={eyeBlink} squint={squint} side="left" />
      <Eye position={[0.22, 0.12, 0.72]} primaryColor={primaryColor} eyeBlink={eyeBlink} squint={squint} side="right" />

      {/* Eyebrows - holographic arched */}
      <group position={[-0.22, 0.28, 0.68]}>
        <mesh rotation={[0.1, 0, 0.18]}>
          <capsuleGeometry args={[0.018, 0.13, 6, 10]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.1}
          />
        </mesh>
        <mesh position={[0, 0.02, 0.01]} rotation={[0.1, 0, 0.18]}>
          <capsuleGeometry args={[0.008, 0.1, 4, 8]} />
          <meshBasicMaterial color={primaryColor} transparent opacity={0.2} />
        </mesh>
      </group>
      <group position={[0.22, 0.28, 0.68]}>
        <mesh rotation={[0.1, 0, -0.18]}>
          <capsuleGeometry args={[0.018, 0.13, 6, 10]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.1}
          />
        </mesh>
        <mesh position={[0, 0.02, 0.01]} rotation={[0.1, 0, -0.18]}>
          <capsuleGeometry args={[0.008, 0.1, 4, 8]} />
          <meshBasicMaterial color={primaryColor} transparent opacity={0.2} />
        </mesh>
      </group>
      
      {/* Nose - holographic */}
      <group position={[0, -0.02, 0.85]}>
        {/* Nose bridge */}
        <mesh position={[0, 0.12, -0.08]} rotation={[0.2, 0, 0]}>
          <capsuleGeometry args={[0.018, 0.12, 6, 8]} />
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        {/* Nose tip */}
        <Sphere args={[0.04, 16, 16]} scale={[0.9, 0.65, 0.85]}>
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.05}
          />
        </Sphere>
        {/* Nostrils */}
        <Sphere args={[0.018, 12, 12]} position={[-0.025, -0.015, -0.01]} scale={[0.8, 0.6, 0.5]}>
          <meshBasicMaterial color={HOLO_DARK} />
        </Sphere>
        <Sphere args={[0.018, 12, 12]} position={[0.025, -0.015, -0.01]} scale={[0.8, 0.6, 0.5]}>
          <meshBasicMaterial color={HOLO_DARK} />
        </Sphere>
        {/* Nose highlight - cyan */}
        <Sphere args={[0.012, 12, 12]} position={[0, 0.01, 0.03]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.2} />
        </Sphere>
      </group>

      {/* Lips - HOLOGRAPHIC CYAN (no pink/red) */}
      <group position={[0, -0.24, 0.78]}>
        {/* Upper lip - Cupid's bow shape */}
        <group>
          <Sphere args={[0.055, 32, 16]} scale={[1.4, 0.3 + mouthOpen * 0.15, 0.55]} position={[-0.03, 0.02, 0]}>
            <meshStandardMaterial 
              color={HOLO_MID}
              metalness={0.9} 
              roughness={0.15}
              emissive={primaryColor}
              emissiveIntensity={0.15}
            />
          </Sphere>
          <Sphere args={[0.055, 32, 16]} scale={[1.4, 0.3 + mouthOpen * 0.15, 0.55]} position={[0.03, 0.02, 0]}>
            <meshStandardMaterial 
              color={HOLO_MID}
              metalness={0.9} 
              roughness={0.15}
              emissive={primaryColor}
              emissiveIntensity={0.15}
            />
          </Sphere>
          {/* Cupid's bow center */}
          <Sphere args={[0.02, 16, 16]} scale={[1, 0.6, 0.8]} position={[0, 0.03, 0.02]}>
            <meshBasicMaterial color={primaryColor} transparent opacity={0.3} />
          </Sphere>
        </group>
        
        {/* Lower lip */}
        <Sphere 
          args={[0.08, 32, 16]} 
          scale={[1.35, 0.4 + mouthOpen * 0.4, 0.55]} 
          position={[0, -0.035 - mouthOpen * 0.04, 0]}
        >
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.15}
          />
        </Sphere>
        
        {/* Lip highlight - cyan */}
        <Sphere args={[0.025, 16, 16]} position={[0.02, -0.02, 0.03]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.25} />
        </Sphere>
        
        {/* Inner mouth darkness when speaking */}
        {mouthOpen > 0.1 && (
          <Sphere args={[0.06, 16, 16]} scale={[1.2, mouthOpen * 1.5, 0.4]} position={[0, -0.01, -0.02]}>
            <meshBasicMaterial color={HOLO_DARK} />
          </Sphere>
        )}
        
        {/* Holographic lip glow */}
        <Sphere args={[0.1, 16, 16]} scale={[1.4, 0.5, 0.4]} position={[0, 0, 0.02]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.1 + mouthOpen * 0.15} />
        </Sphere>
      </group>

      {/* Chin definition - holographic */}
      <Sphere args={[0.1, 16, 16]} position={[0, -0.45, 0.6]} scale={[0.9, 0.6, 0.7]}>
        <meshStandardMaterial 
          color={HOLO_MID}
          metalness={0.9} 
          roughness={0.15}
          emissive={primaryColor}
          emissiveIntensity={0.03}
        />
      </Sphere>
      
      {/* Jaw line */}
      <group position={[0, -0.35, 0.35]}>
        <Sphere args={[0.08, 12, 12]} position={[-0.28, 0, 0.1]} scale={[1, 0.6, 0.7]}>
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.03}
          />
        </Sphere>
        <Sphere args={[0.08, 12, 12]} position={[0.28, 0, 0.1]} scale={[1, 0.6, 0.7]}>
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.9} 
            roughness={0.15}
            emissive={primaryColor}
            emissiveIntensity={0.03}
          />
        </Sphere>
      </group>
    </group>
  );
}

// Holographic athletic female body component
function HolographicBody({ primaryColor }: { primaryColor: string }) {
  const bodyRef = useRef<THREE.Group>(null!);
  
  useFrame((state) => {
    if (bodyRef.current) {
      // Subtle body sway
      bodyRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 0.4) * 0.01;
    }
  });

  return (
    <group ref={bodyRef} position={[0, -1.9, 0]}>
      {/* Neck */}
      <mesh position={[0, 0.85, 0]}>
        <cylinderGeometry args={[0.11, 0.14, 0.32, 32]} />
        <meshStandardMaterial 
          color={HOLO_DARK}
          metalness={0.92} 
          roughness={0.12}
          emissive={primaryColor}
          emissiveIntensity={0.05}
        />
      </mesh>
      <Torus args={[0.13, 0.012, 16, 32]} rotation={[Math.PI / 2, 0, 0]} position={[0, 0.7, 0]}>
        <meshBasicMaterial color={primaryColor} transparent opacity={0.6} />
      </Torus>

      {/* Shoulders */}
      <group position={[0, 0.55, 0]}>
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[0.11, 0.55, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        {/* Shoulder caps */}
        <Sphere args={[0.1, 16, 16]} position={[-0.35, 0, 0]}>
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.95} 
            roughness={0.1}
            emissive={primaryColor}
            emissiveIntensity={0.06}
          />
        </Sphere>
        <Sphere args={[0.1, 16, 16]} position={[0.35, 0, 0]}>
          <meshStandardMaterial 
            color={HOLO_MID}
            metalness={0.95} 
            roughness={0.1}
            emissive={primaryColor}
            emissiveIntensity={0.06}
          />
        </Sphere>
      </group>

      {/* Torso */}
      <group position={[0, 0, 0]}>
        {/* Upper chest */}
        <Sphere args={[0.32, 32, 32]} scale={[1.15, 0.75, 0.65]} position={[0, 0.25, 0.05]}>
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </Sphere>
        
        {/* Core/waist */}
        <mesh position={[0, -0.2, 0]}>
          <cylinderGeometry args={[0.19, 0.24, 0.45, 32]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        
        {/* Energy lines */}
        {[-0.05, 0, 0.05].map((y, i) => (
          <mesh key={i} position={[0, -0.1 + y * 2, 0.18]} rotation={[0, 0, 0]}>
            <boxGeometry args={[0.15, 0.008, 0.01]} />
            <meshBasicMaterial color={primaryColor} transparent opacity={0.3} />
          </mesh>
        ))}
        
        {/* Waist ring */}
        <Torus args={[0.21, 0.012, 16, 32]} rotation={[Math.PI / 2, 0, 0]} position={[0, -0.05, 0]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.5} />
        </Torus>

        {/* Hips */}
        <Sphere args={[0.28, 32, 32]} scale={[1.25, 0.65, 0.75]} position={[0, -0.5, 0]}>
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </Sphere>
        <Torus args={[0.32, 0.012, 16, 32]} rotation={[Math.PI / 2, 0, 0]} position={[0, -0.5, 0]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.4} />
        </Torus>
      </group>

      {/* Left Arm */}
      <group position={[-0.45, 0.45, 0]}>
        <mesh position={[-0.1, -0.22, 0]} rotation={[0, 0, 0.15]}>
          <capsuleGeometry args={[0.055, 0.32, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        <Sphere args={[0.04, 12, 12]} position={[-0.08, -0.15, 0.04]} scale={[1.2, 1.5, 0.8]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.12} />
        </Sphere>
        <Sphere args={[0.048, 16, 16]} position={[-0.16, -0.45, 0]}>
          <meshStandardMaterial color={HOLO_MID} metalness={0.95} roughness={0.1} emissive={primaryColor} emissiveIntensity={0.05} />
        </Sphere>
        <mesh position={[-0.2, -0.7, 0.04]} rotation={[0.15, 0, 0.12]}>
          <capsuleGeometry args={[0.042, 0.32, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        <Torus args={[0.045, 0.008, 8, 32]} rotation={[0.15, 0, 0.12]} position={[-0.22, -0.88, 0.06]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.6} />
        </Torus>
        <group position={[-0.24, -0.98, 0.08]}>
          <Sphere args={[0.04, 16, 16]} scale={[0.75, 1.1, 0.45]}>
            <meshStandardMaterial color={HOLO_MID} metalness={0.92} roughness={0.12} emissive={primaryColor} emissiveIntensity={0.04} />
          </Sphere>
          {[0, 1, 2, 3].map((i) => (
            <mesh key={i} position={[(i - 1.5) * 0.015, -0.06, 0]} rotation={[0.1, 0, 0]}>
              <capsuleGeometry args={[0.008, 0.04, 4, 6]} />
              <meshStandardMaterial color={HOLO_MID} metalness={0.92} roughness={0.12} />
            </mesh>
          ))}
        </group>
      </group>

      {/* Right Arm */}
      <group position={[0.45, 0.45, 0]}>
        <mesh position={[0.1, -0.22, 0]} rotation={[0, 0, -0.15]}>
          <capsuleGeometry args={[0.055, 0.32, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        <Sphere args={[0.04, 12, 12]} position={[0.08, -0.15, 0.04]} scale={[1.2, 1.5, 0.8]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.12} />
        </Sphere>
        <Sphere args={[0.048, 16, 16]} position={[0.16, -0.45, 0]}>
          <meshStandardMaterial color={HOLO_MID} metalness={0.95} roughness={0.1} emissive={primaryColor} emissiveIntensity={0.05} />
        </Sphere>
        <mesh position={[0.2, -0.7, 0.04]} rotation={[0.15, 0, -0.12]}>
          <capsuleGeometry args={[0.042, 0.32, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        <Torus args={[0.045, 0.008, 8, 32]} rotation={[0.15, 0, -0.12]} position={[0.22, -0.88, 0.06]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.6} />
        </Torus>
        <group position={[0.24, -0.98, 0.08]}>
          <Sphere args={[0.04, 16, 16]} scale={[0.75, 1.1, 0.45]}>
            <meshStandardMaterial color={HOLO_MID} metalness={0.92} roughness={0.12} emissive={primaryColor} emissiveIntensity={0.04} />
          </Sphere>
          {[0, 1, 2, 3].map((i) => (
            <mesh key={i} position={[(i - 1.5) * 0.015, -0.06, 0]} rotation={[0.1, 0, 0]}>
              <capsuleGeometry args={[0.008, 0.04, 4, 6]} />
              <meshStandardMaterial color={HOLO_MID} metalness={0.92} roughness={0.12} />
            </mesh>
          ))}
        </group>
      </group>

      {/* Left Leg */}
      <group position={[-0.16, -0.78, 0]}>
        <Sphere args={[0.09, 16, 16]}>
          <meshStandardMaterial color={HOLO_MID} metalness={0.95} roughness={0.1} emissive={primaryColor} emissiveIntensity={0.05} />
        </Sphere>
        <mesh position={[0, -0.32, 0]}>
          <capsuleGeometry args={[0.08, 0.4, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        <Sphere args={[0.04, 12, 12]} position={[0, -0.25, 0.06]} scale={[1.5, 2, 0.8]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.1} />
        </Sphere>
        <Sphere args={[0.06, 16, 16]} position={[0, -0.58, 0.02]}>
          <meshStandardMaterial color={HOLO_MID} metalness={0.95} roughness={0.1} emissive={primaryColor} emissiveIntensity={0.05} />
        </Sphere>
        <Torus args={[0.065, 0.008, 8, 32]} rotation={[Math.PI / 2, 0, 0]} position={[0, -0.58, 0.02]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.4} />
        </Torus>
        <mesh position={[0, -0.9, 0]}>
          <capsuleGeometry args={[0.055, 0.42, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        <Torus args={[0.04, 0.008, 8, 32]} rotation={[Math.PI / 2, 0, 0]} position={[0, -1.18, 0]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.5} />
        </Torus>
        <mesh position={[0, -1.28, 0.05]} rotation={[0.25, 0, 0]}>
          <boxGeometry args={[0.07, 0.045, 0.16]} />
          <meshStandardMaterial color={HOLO_MID} metalness={0.95} roughness={0.1} emissive={primaryColor} emissiveIntensity={0.04} />
        </mesh>
      </group>

      {/* Right Leg */}
      <group position={[0.16, -0.78, 0]}>
        <Sphere args={[0.09, 16, 16]}>
          <meshStandardMaterial color={HOLO_MID} metalness={0.95} roughness={0.1} emissive={primaryColor} emissiveIntensity={0.05} />
        </Sphere>
        <mesh position={[0, -0.32, 0]}>
          <capsuleGeometry args={[0.08, 0.4, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        <Sphere args={[0.04, 12, 12]} position={[0, -0.25, 0.06]} scale={[1.5, 2, 0.8]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.1} />
        </Sphere>
        <Sphere args={[0.06, 16, 16]} position={[0, -0.58, 0.02]}>
          <meshStandardMaterial color={HOLO_MID} metalness={0.95} roughness={0.1} emissive={primaryColor} emissiveIntensity={0.05} />
        </Sphere>
        <Torus args={[0.065, 0.008, 8, 32]} rotation={[Math.PI / 2, 0, 0]} position={[0, -0.58, 0.02]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.4} />
        </Torus>
        <mesh position={[0, -0.9, 0]}>
          <capsuleGeometry args={[0.055, 0.42, 8, 16]} />
          <meshStandardMaterial 
            color={HOLO_DARK}
            metalness={0.92} 
            roughness={0.12}
            emissive={primaryColor}
            emissiveIntensity={0.04}
          />
        </mesh>
        <Torus args={[0.04, 0.008, 8, 32]} rotation={[Math.PI / 2, 0, 0]} position={[0, -1.18, 0]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.5} />
        </Torus>
        <mesh position={[0, -1.28, 0.05]} rotation={[0.25, 0, 0]}>
          <boxGeometry args={[0.07, 0.045, 0.16]} />
          <meshStandardMaterial color={HOLO_MID} metalness={0.95} roughness={0.1} emissive={primaryColor} emissiveIntensity={0.04} />
        </mesh>
      </group>

      {/* Core energy glow */}
      <Sphere args={[0.12, 16, 16]} position={[0, -0.05, 0.15]}>
        <meshBasicMaterial color={primaryColor} transparent opacity={0.2} />
      </Sphere>
    </group>
  );
}

function AvatarMesh({ speaking, listening, expression }: AvatarMeshProps) {
  const groupRef = useRef<THREE.Group>(null);
  const glowRef = useRef<THREE.Mesh>(null);
  const [mouthOpen, setMouthOpen] = useState(0);
  const [eyeBlink, setEyeBlink] = useState(0);
  const [squint, setSquint] = useState(0);
  
  // Mouth movement when speaking
  useEffect(() => {
    if (!speaking) {
      setMouthOpen(0);
      return;
    }
    
    const interval = setInterval(() => {
      setMouthOpen(Math.random() * 0.5 + 0.1);
    }, 100);
    
    return () => clearInterval(interval);
  }, [speaking]);
  
  // Natural eye blinking
  useEffect(() => {
    const blink = () => {
      setEyeBlink(1);
      setTimeout(() => setEyeBlink(0), 120 + Math.random() * 60);
    };
    
    const doubleBlink = () => {
      blink();
      setTimeout(() => blink(), 200);
    };
    
    const scheduleNextBlink = () => {
      const delay = 2500 + Math.random() * 3500;
      const timer = setTimeout(() => {
        if (Math.random() > 0.85) {
          doubleBlink();
        } else {
          blink();
        }
        scheduleNextBlink();
      }, delay);
      return timer;
    };
    
    const timer = scheduleNextBlink();
    return () => clearTimeout(timer);
  }, []);

  // Squint when listening
  useEffect(() => {
    if (listening) {
      setSquint(0.2);
    } else {
      setSquint(0);
    }
  }, [listening]);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.8) * 0.025;
      
      if (listening) {
        groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, 0.06, 0.04);
      } else {
        groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, 0, 0.04);
      }
    }

    if (glowRef.current) {
      const material = glowRef.current.material as THREE.MeshBasicMaterial;
      material.opacity = 0.06 + Math.sin(state.clock.elapsedTime * 2) * 0.03;
    }
  });

  // All expressions use cyan/teal holographic colors
  const getExpressionColor = () => {
    switch (expression) {
      case 'happy': return '#00ffcc';    // Bright green-cyan
      case 'sad': return '#00a8ff';      // Blue-cyan
      case 'angry': return '#00ffaa';    // Teal
      case 'surprised': return '#00e8d4'; // Turquoise
      default: return '#00d4ff';         // Default cyan
    }
  };

  const primaryColor = getExpressionColor();

  return (
    <Float speed={1.2} rotationIntensity={0.08} floatIntensity={0.15}>
      <group ref={groupRef}>
        {/* Outer aura glow */}
        <Sphere ref={glowRef} args={[1.8, 32, 32]}>
          <meshBasicMaterial color={primaryColor} transparent opacity={0.06} side={THREE.BackSide} />
        </Sphere>

        {/* Head */}
        <group>
          {/* Main head shape - holographic */}
          <group scale={[0.7, 0.9, 0.75]}>
            <Sphere args={[1, 64, 64]}>
              <meshStandardMaterial
                color={HOLO_DARK}
                metalness={0.92}
                roughness={0.1}
                emissive={primaryColor}
                emissiveIntensity={0.03}
              />
            </Sphere>
          </group>

          {/* Forehead highlight */}
          <Sphere args={[0.25, 32, 32]} position={[0, 0.55, 0.45]} scale={[1.8, 0.5, 0.4]}>
            <meshBasicMaterial color={primaryColor} transparent opacity={0.08} />
          </Sphere>

          {/* Inner face area */}
          <group scale={[0.67, 0.85, 0.7]}>
            <Sphere args={[0.98, 64, 64]} position={[0, 0, 0.08]}>
              <meshStandardMaterial
                color={HOLO_MID}
                metalness={0.88}
                roughness={0.15}
                emissive={primaryColor}
                emissiveIntensity={0.02}
              />
            </Sphere>
          </group>

          {/* Ears */}
          <Ear side="left" primaryColor={primaryColor} />
          <Ear side="right" primaryColor={primaryColor} />

          {/* Face features */}
          <HolographicFace primaryColor={primaryColor} mouthOpen={mouthOpen} eyeBlink={eyeBlink} squint={squint} />

          {/* Tech circuit lines on head */}
          <Torus args={[0.68, 0.008, 16, 100]} rotation={[Math.PI / 2, 0, 0]} position={[0, 0.4, 0]}>
            <meshBasicMaterial color={primaryColor} transparent opacity={0.4} />
          </Torus>
          <Torus args={[0.64, 0.006, 16, 100]} rotation={[Math.PI / 2, 0, 0]} position={[0, -0.18, 0]}>
            <meshBasicMaterial color={primaryColor} transparent opacity={0.25} />
          </Torus>

          {/* Holographic Hair */}
          <HolographicHair primaryColor={primaryColor} />
        </group>

        {/* Holographic Full Body */}
        <HolographicBody primaryColor={primaryColor} />

        {/* Orbiting holographic rings */}
        <HoloRing radius={1.1} speed={0.4} color={primaryColor} yPos={0.2} />
        <HoloRing radius={1.25} speed={-0.25} color={HOLO_SECONDARY} yPos={-0.5} />
        <HoloRing radius={0.95} speed={0.55} color={HOLO_ACCENT} yPos={-1.2} />

        {/* Holographic sparkles/particles */}
        <Sparkles
          count={80}
          scale={4}
          size={2}
          speed={0.4}
          color={primaryColor}
          opacity={0.5}
        />

        {/* Data stream effects when speaking */}
        {speaking && (
          <group>
            <Sparkles
              count={50}
              scale={2}
              size={3}
              speed={2}
              color={HOLO_GLOW}
              opacity={0.7}
              position={[0, -0.2, 0.8]}
            />
          </group>
        )}
      </group>
    </Float>
  );
}

// Camera controller - starts focused on head
function CameraController() {
  const { camera } = useThree();
  
  useEffect(() => {
    camera.position.set(0, 0.3, 2.5);
    camera.lookAt(0, 0.2, 0);
  }, [camera]);

  return null;
}

interface Avatar3DProps {
  speaking?: boolean;
  listening?: boolean;
  expression?: string;
}

export function Avatar3D({ 
  speaking = false, 
  listening = false, 
  expression = 'neutral' 
}: Avatar3DProps) {
  return (
    <div className="w-full h-full">
      <Canvas
        camera={{ position: [0, 0.3, 2.5], fov: 50 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: 'transparent' }}
      >
        <CameraController />
        
        {/* Lighting for holographic effect */}
        <ambientLight intensity={0.3} color="#00ffff" />
        <pointLight position={[3, 3, 3]} intensity={0.8} color="#00d4ff" />
        <pointLight position={[-3, 2, 2]} intensity={0.5} color="#00ffcc" />
        <pointLight position={[0, -3, 2]} intensity={0.3} color="#40e0d0" />
        <spotLight
          position={[0, 5, 5]}
          angle={0.4}
          penumbra={1}
          intensity={0.6}
          color="#00d4ff"
        />
        
        <AvatarMesh speaking={speaking} listening={listening} expression={expression} />
        
        <OrbitControls 
          enablePan={false}
          minDistance={1.5}
          maxDistance={6}
          minPolarAngle={Math.PI / 6}
          maxPolarAngle={Math.PI / 1.5}
          target={[0, 0, 0]}
        />
      </Canvas>
    </div>
  );
}
